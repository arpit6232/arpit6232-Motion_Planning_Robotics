# Algorithamic_Motion_Planning

BUG  1  and  BUG  2  algorithms  for  a  left-turning  robot  in  Python  and consider two workspaces W1 and W2


 - To Run the files 

1) python algo_buys.py 

 Enter 1 for Workspace 1 or  for Workspace 2 
Input 1 or 2
 Enter 1 for using Bug-1 Algorithm or 2 for Bug-2 Algorithm 
Input 1 or 2


2) A plot is generated 

